class MyWebComponent extends HTMLElement {
    constructor() {
        super();
        const shadowRoot = this.attachShadow({ mode: 'open' });
        console.log()
        shadowRoot.innerHTML = `
      <style>
        *{
    margin:0;
    padding:0;
}
.card {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 200px;
    padding: 15px;
    border-radius: 3px;
    margin: 10px;
    box-shadow: 0px 5px 13px grey;
}

    img {
        width: 100%;
        max-height: 150px;
        margin-bottom: 20px;
    }

    .details {
        display: flex;
        width: 100%;
    justify-content: space-around;
    }

        .btn {
            background-color: #008CBA;
            color: #fff;
            font-size: 9px;
            padding: 4px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 10px;
        }
    
        .btn:hover {
            background-color: #006080;
        }
        .container{
            display:flex;
        }
      </style>
      <div class="card">
  <img src="${this.getAttribute('image')}" alt="Product Image" />
  <div class="details">
    <p>${this.getAttribute('name')}</p>
    <p>${this.getAttribute('price')}</p>
  </div>
  <button class="btn">Buy</button>
  </div>
    `;
        const button = shadowRoot.querySelector('button');
        button.addEventListener('click', () => {
            alert('Hey this is my component');
        });
    }
}
customElements.define('my-web-component', MyWebComponent);
