const formElem = document.getElementById("form-container");
formElem.onsubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(formElem);
    console.log("Form Data");
    for (let obj of formData) {
        console.log(obj);
    }
    formElem.reset();
};