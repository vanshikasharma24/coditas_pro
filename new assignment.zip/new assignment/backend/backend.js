import database from "./database";

function dummyFetch(url) {
  const responseData = database;
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve({
        json: () => Promise.resolve(responseData),
      });
    }, 2000);
  });
}