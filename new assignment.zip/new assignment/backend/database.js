let database = [];
const formElem = document.getElementById("form-container");
formElem.onsubmit = (e) => {
  e.preventDefault();
  const formData = new FormData(formElem);
  console.log("Form Data");
  for (let data of formData) {
    console.log(data);
    database.push(data)
  }
  formElem.reset();
};

// const formElem = document.getElementById("form-container");
// formElem.addEventListener("input", (e) => {
//   e.preventDefault();
//   const formData = new FormData(formElem);
//   console.log("Form Data:");
//   for (let [key, value] of formData.entries()) {
//     console.log(`${key}: ${value}`);
//     database.push([key,value])
//   }
//   formElem.reset();
// });
// console.log(database)

export default{
  database,
  formElem
}


