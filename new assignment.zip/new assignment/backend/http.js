const post=async(endpoint,data={})=>{
    if(!endpoint.startsWith("/"))throw "INVALID ENDPOINT"
const response=await fetch(`http://localhost:3000 ${endpoint}`,{//fetch creates a http request
    method:'POST',
    headers:{
        'Content-Type':`application/json`
    },
    body:JSON.stringify(data)
});
const data=await response.json();
if(response.status!==200 && response.status!=201){
    throw{message:data?.error?.message}
}
return data
}