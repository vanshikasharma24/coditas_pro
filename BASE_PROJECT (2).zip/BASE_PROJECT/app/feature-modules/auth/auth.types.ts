export interface ICredentials {
  email: string;
  password: string;
}
export type Payload = { id: string; role: string };
