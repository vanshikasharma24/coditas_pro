export interface INotification{
    senderId:string,
    receiverId:string,
    tournamentId?:string,
    Notmessge?:string,
}